'use client';

import Link from 'next/link';
import { useSession, signOut } from 'next-auth/react';
import { useState } from 'react';
import { usePathname } from 'next/navigation';

export default function Navbar() {
  const { data: session } = useSession();
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navLink = (href: string, label: string) => (
    <Link
      href={href}
      className={`text-sm font-medium transition hover:text-blue-600 ${
        pathname === href ? 'text-blue-600' : 'text-gray-700'
      }`}
    >
      {label}
    </Link>
  );

  return (
    <nav className="sticky top-0 z-50 bg-white border-b shadow-sm">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo / Home link */}
          <Link href="/" className="text-4xl font-semibold text-blue-600 tracking-tight">
            CampusConnect
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center space-x-6">
            {navLink('/listings', 'Listings')}
            {session?.user && navLink('/dashboard', 'Dashboard')}
            {session?.user && navLink('/listings/create', 'Create')}

            {session?.user ? (
              <button
                onClick={() => signOut()}
                className="px-3 py-1.5 rounded-md text-sm font-medium bg-red-50 text-red-600 hover:bg-red-100 transition"
              >
                Sign Out
              </button>
            ) : (
              navLink('/auth/signin', 'Sign In')
            )}
          </div>

          {/* Mobile toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden text-gray-600"
            aria-label="Toggle Menu"
          >
            {mobileOpen ? '✖' : '☰'}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden px-4 pb-4 space-y-2 border-t bg-white shadow-inner">
          {navLink('/listings', 'Listings')}
          {session?.user && navLink('/dashboard', 'Dashboard')}
          {session?.user && navLink('/listings/create', 'Create')}

          {session?.user ? (
            <button
              onClick={() => signOut()}
              className="block w-full text-left px-3 py-1.5 rounded-md text-sm font-medium bg-red-50 text-red-600 hover:bg-red-100 transition"
            >
              Sign Out
            </button>
          ) : (
            navLink('/auth/signin', 'Sign In')
          )}
        </div>
      )}
    </nav>
  );
}
